# ORBIT STUDIO 3.0 — Android APK

APK natif WebView: les cinq ateliers et la bibliothèque fonctionnent directement dans l'application.
**Termux n'est plus nécessaire.** L'interface et les projets enregistrés sont disponibles hors ligne.

## Installation

Télécharger l'APK `app-debug.apk` depuis le build GitHub Actions. Ouvrir le fichier APK sur Android et confirmer l'installation (éventuellement autoriser les sources externes dans Android). Aucun outil sur PC n'est nécessaire.

## Connexions IA

Appuyer sur **Connexions IA** dans le bandeau, sélectionner fournisseur compatible OpenAI ou **Ollama distant**, saisir les données puis sauvegarder. Pour images, vidéos et musique, saisir la clé **Replicate**.

Le modèle `orcarouter/Qwen3.8-Flash-Next-Uncensored` ne peut pas être intégré localement sur la majorité des Android (quantification la plus légère ~174 Go, MLX Apple Silicon). Ce modèle ne fonctionne qu'à travers un **serveur Ollama externe compatible**, sur un ordinateur approprié ou un fournisseur qui l'héberge.

**Attention:** les services distants peuvent facturer les générations. Aucune clé API n'est incluse, les clés sont sauvegardées localement dans les préférences Android (non chiffrées par défaut). Ne partagez jamais vos identifiants. Les médias générés restent hébergés à distance jusqu'à leur téléchargement. Le bouton Exporter télécharge le fichier via Android; les projets textuels peuvent être sauvegardés localement.

## Source

Projet Gradle / Android SDK, compilation `gradle :app:assembleDebug`.
L'APK de debug est installable mais sa signature n'est pas une signature de publication Play Store. Les mises à jour nécessiteront une signature cohérente.
