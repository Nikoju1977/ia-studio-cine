/* ORBIT Android bridge: the AI credentials never enter the browser JavaScript. */
(() => {
  'use strict';
  if (!window.OrbitNative) return;
  const nativeFetch = window.fetch.bind(window);
  let nextId = 0;
  const waiting = new Map();
  window.__orbitReply = (id, responseText) => {
    const pair = waiting.get(id);
    if (!pair) return;
    waiting.delete(id);
    try { pair.resolve(JSON.parse(responseText)); }
    catch (e) { pair.reject(e); }
  };
  window.fetch = (input, options = {}) => {
    const url = typeof input === 'string' ? input : String(input?.url || '');
    if (!url.startsWith('/api/')) return nativeFetch(input, options);
    const method = String(options?.method || 'GET').toUpperCase();
    const payload = options?.body || '{}';
    const id = String(++nextId);
    return new Promise((resolve, reject) => {
      waiting.set(id, {resolve, reject});
      try { window.OrbitNative.request(id, method, url, String(payload)); }
      catch (e) {waiting.delete(id);reject(e);}
    }).then(result => new Response(JSON.stringify(result.data || {}), {
      status: result.status || 502,
      headers: {'Content-Type':'application/json'}
    }));
  };
  const addSettings = () => {
    const top = document.querySelector('.topbar-right');
    if (!top || document.getElementById('native-settings')) return;
    const btn = document.createElement('button');
    btn.id = 'native-settings';
    btn.className = 'topbar-create';
    btn.style.cssText = 'background:#7650ff;color:white;border-radius:10px;min-width:max-content;padding:10px 12px;';
    btn.textContent = '⚙ Connexions IA';
    btn.addEventListener('click', () => window.OrbitNative.configure());
    top.insertBefore(btn, top.firstChild);
  };
  document.addEventListener('DOMContentLoaded', () => {
    document.getElementById('pwa-install')?.remove();
    document.getElementById('pwa-install-settings')?.remove();
    addSettings();
    const observer = new MutationObserver(() => {
      addSettings();
      const pwa = document.getElementById('pwa-install-settings');
      if (pwa) {
        pwa.textContent = 'Configurer mes moteurs IA';
        pwa.onclick = () => window.OrbitNative.configure();
      }
    });
    observer.observe(document.body, {childList:true,subtree:true});
  });
})();
