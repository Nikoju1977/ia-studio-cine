/* ORBIT Studio — interactive creative workspace (no JS dependencies). */
'use strict';
const $ = (id) => document.getElementById(id);
const root = $('view-root');
const icons = {home:'grid',image:'image',video:'video',scenario:'feather',music:'music',app:'code',library:'folder',settings:'settings'};
const names = {home:"Vue d'ensemble",image:'Images IA',video:'Studio vidéo',scenario:'Scénarios',music:'Musique & son',app:'App Builder',library:'Bibliothèque',settings:'Paramètres'};
const subtitles = {
  image:'Donnez vie à vos visions, du concept à l’image finale.',
  video:'Transformez vos idées en séquences cinématographiques.',
  scenario:'Écrivez des histoires qui méritent le grand écran.',
  music:'Composez des ambiances et des bandes originales.',
  app:'Imaginez, générez et prévisualisez une application web.'
};
const sources = {image:'FLUX.1 Schnell',video:'Google Veo 3.1 Fast',scenario:'Qwen 3.8',music:'Meta MusicGen',app:'Qwen 3.8'};
const templates = {
  image:{prompt:'',ratio:'16:9',style:'cinématographique'},
  video:{prompt:'',ratio:'16:9',duration:'8',audio:true,style:'cinématographique'},
  scenario:{prompt:'',format:'Court métrage',tone:'Poétique',length:'5 à 8 pages'},
  music:{prompt:'',duration:'12',mood:'Cinématique',instrumental:true},
  app:{prompt:'',category:'Application web',style:'Minimal & moderne'}
};
const suggestions = {
  image:['Un portrait au clair-obscur','Une planète au crépuscule','Un paysage brutaliste'],
  video:['Un plan séquence immersif','Une forêt en lumière dorée','Une ville cyberpunk sous la pluie'],
  scenario:['Un thriller philosophique','Une rencontre impossible','Un récit de science-fiction'],
  music:['Une bande-son atmosphérique','Piano mélancolique','Ambient électronique'],
  app:['Un portfolio de réalisateur','Un gestionnaire de projets créatifs','Une galerie photographique']
};
const stored = (() => {try {return JSON.parse(localStorage.getItem('orbit-studio-v1')||'[]')||[];}catch{return []}})();
const state = {view:'home',projects:Array.isArray(stored)?stored:[],drafts:structuredClone(templates),results:{},busy:new Set(),tab:'preview',filter:'all',search:'',status:null,modal:null,activeJobs:new Set()};
const svg = (icon, cls='') => `<svg class="${cls}" aria-hidden="true"><use href="#i-${icon}"/></svg>`;
const esc = (v='') => String(v??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const short = (text='', length=70) => String(text).replace(/\s+/g,' ').slice(0,length) + (String(text).length>length?'…':'');
const byDate = (a,b)=>new Date(b.createdAt)-new Date(a.createdAt);
const when = (date) => {try{return new Date(date).toLocaleDateString('fr-FR',{day:'2-digit',month:'short',year:'numeric'});}catch{return '—'}};
function save(){
  try{localStorage.setItem('orbit-studio-v1',JSON.stringify(state.projects));}catch{toast('Stockage du navigateur saturé. Exporte tes projets.','error')}
  $('nav-count').textContent = String(state.projects.length);
}
function toast(message,type='info'){
  const el=document.createElement('div');el.className='toast '+type;el.textContent=message;$('toasts').appendChild(el);
  setTimeout(()=>el.remove(),5200);
}
function setStatus(){
  const s=state.status;
  const has = Boolean(s&&(s.replicate||s.llm_configured));
  $('status-dot').classList.toggle('connected',has);
  $('model-dot').classList.toggle('connected',Boolean(s?.llm_configured));
  $('status-text').textContent=s?(s.replicate&&s.llm_configured?'Moteurs connectés':s.replicate?'Multimédia connecté':s.llm_configured?'Moteur texte disponible':'Configuration requise'):'Serveur non connecté';
}
async function refreshStatus(){
  try{let r=await fetch('/api/status');if(!r.ok)throw new Error();state.status=await r.json();}
  catch{state.status=null;}
  setStatus();if(state.view==='settings')render();
}
function navigate(view){
  if(!names[view])return;
  state.view=view;state.modal=null;closeModal();
  $('breadcrumb-current').textContent=names[view];
  document.querySelectorAll('[data-view]').forEach(el=>{if(el.classList.contains('nav-item'))el.classList.toggle('active',el.dataset.view===view)});
  $('sidebar').classList.remove('open');$('mobile-backdrop').classList.remove('open');
  render();window.scrollTo({top:0,behavior:'instant'});
}
function header(title,sub='',eyebrow='ORBIT CREATIVE STUDIO'){
  return `<div class="page-head"><div><div class="page-eyebrow">${esc(eyebrow)}</div><h1>${esc(title)}</h1><p>${esc(sub)}</p></div></div>`;
}
function tileArt(kind){
  switch(kind){
    case 'image':return `<div class="tile-art tile-art-image"><div class="art-sun"></div><div class="art-mountain"></div><div class="art-mountain"></div></div>`;
    case 'video':return `<div class="tile-art tile-art-video"><div class="art-cinematic"></div><span class="art-play">${svg('play')}</span></div>`;
    case 'scenario':return `<div class="tile-art tile-art-scenario"><div class="art-paper"><span></span><span></span><span></span><span></span><span></span></div></div>`;
    case 'music':return `<div class="tile-art tile-art-music"><div class="art-bars">${Array(9).fill('<span></span>').join('')}</div></div>`;
    default:return `<div class="tile-art tile-art-app"><div class="art-window"><div class="art-window-top"><i></i><i></i><i></i></div><div class="art-window-body"><span></span><span></span><span></span></div></div></div>`;
  }
}
function homeView(){
 const n=state.projects.length;const media=state.projects.filter(p=>['image','video','music'].includes(p.kind)&&p.status==='succeeded').length;
 const recents=[...state.projects].sort(byDate).slice(0,4);
 const tiles=[
   ['image','GÉNÉRATION VISUELLE','Créer des images','Photographie & illustration','FLUX.1'],
   ['video','CRÉATION CINÉMA','Studio vidéo','Séquences & motion','Veo 3.1'],
   ['scenario','ÉCRITURE IA','Scénarios','Histoires & dialogues','Qwen'],
   ['music','PRODUCTION AUDIO','Musique & son','Ambiances & BO','MusicGen'],
   ['app','DÉVELOPPEMENT IA','App Builder','Interfaces & outils','Qwen']];
 return `<div class="page-head"><div><div class="page-eyebrow">VOTRE ESPACE DE CRÉATION</div><h1>Bienvenue dans votre studio <span style="color:#8a72e1">✳</span></h1><p>Tout votre univers créatif, réuni au même endroit.</p></div><button class="top-link" data-view="library">Voir mes projets ${svg('arrow')}</button></div>
 <section class="hero"><div class="hero-content"><div class="hero-badge"><span></span> UN STUDIO, DES POSSIBILITÉS INFINIES</div><h2>Votre imagination.<br/><em>Sans frontières.</em></h2><p>De la première idée à la création finale. Explorez, imaginez et produisez avec la puissance de l'intelligence artificielle.</p><button class="hero-btn" data-view="image">Commencer à créer ${svg('arrow')}</button></div><div class="hero-art"><div class="hero-ring"></div><div class="hero-ring"></div><div class="hero-ring"></div><div class="hero-orbit"></div><div class="hero-planet"></div><span class="hero-star">✧</span><span class="hero-star other">✦</span></div></section>
 <div class="stats-bar"><div class="stat"><span class="stat-icon">${svg('folder')}</span><div class="stat-info"><strong>${n}</strong><small>Projets créés</small></div></div><div class="stat"><span class="stat-icon pink">${svg('image')}</span><div class="stat-info"><strong>${media}</strong><small>Médias générés</small></div></div><div class="stat"><span class="stat-icon blue">${svg('sparkles')}</span><div class="stat-info"><strong>5</strong><small>Espaces créatifs</small></div></div></div>
 <div class="section-heading"><div><h2>Que souhaitez-vous créer ?</h2><p>Choisissez votre espace. Chaque idée est un nouveau départ.</p></div></div>
 <div class="tools-grid">${tiles.map(([kind,category,title,desc,source])=>`<button class="tool-tile" data-view="${kind}">${tileArt(kind)}<div class="tile-meta"><div class="tile-category">${category}</div><h3>${title}</h3><p>${desc}</p><div class="tile-footer"><span>${source}</span>${svg('arrow')}</div></div></button>`).join('')}</div>
 <div class="home-lower"><section class="panel recent-panel"><div class="panel-section-title"><h2>Créations récentes</h2><button class="top-link" data-view="library">Tout voir ${svg('arrow')}</button></div>${recents.length?`<div class="project-list">${recents.map(projectRow).join('')}</div>`:`<div class="empty-list">${svg('folder')}<strong>Votre studio attend sa première création</strong>Images, films, scénarios, musiques et applications apparaîtront ici.</div>`}</section>
 <section class="panel inspiration-panel"><div class="decorative-asterisk">✳</div><div class="tiny-kicker">UN PEU D'INSPIRATION ?</div><h3>Les grandes idées commencent ici.</h3><p>Une histoire à raconter, un monde à explorer, une image à imaginer… Lancez votre prochain projet.</p><button class="btn-subtle" data-action="inspire">Trouver une idée ${svg('arrow')}</button></section></div>`;
}
function projectRow(p){
 const subtitle=(p.status==='processing'?'En cours · ':p.status==='failed'?'Échec · ':'')+when(p.createdAt)+' · '+names[p.kind];
 return `<button class="project-row" data-project="${esc(p.id)}"><span class="project-icon ${esc(p.kind)}">${svg(icons[p.kind]||'folder')}</span><span style="min-width:0"><strong>${esc(p.title)}</strong><small>${esc(subtitle)}</small></span>${svg('chevron','row-arrow')}</button>`;
}
function studioView(kind){
 const d=state.drafts[kind];const busy=state.busy.has(kind);
 return `<div class="studio-header"><div class="studio-header-icon ${kind}">${svg(icons[kind])}</div><div><div class="page-eyebrow">ATELIER CRÉATIF · 0${['image','video','scenario','music','app'].indexOf(kind)+1}</div><h1>${names[kind]}</h1><p>${subtitles[kind]}</p></div><span class="engine-pill">MOTEUR · ${sources[kind]}</span></div>
 <div class="studio-layout"><section class="panel form-panel"><h2>Votre brief créatif</h2><p class="form-subtitle">Décrivez précisément votre idée. Plus votre intention est claire, plus le résultat sera pertinent.</p>
 ${promptField(kind,d)}${extrasFields(kind,d)}
 <button class="generate-btn" data-action="generate" data-kind="${kind}" ${busy?'disabled':''}>${busy?'<span class="spinner" style="width:15px;height:15px;border-width:2px"></span> Génération en cours…':svg('sparkles')+(['scenario','app'].includes(kind)?'Créer avec Qwen':'Générer avec l’IA')+svg('arrow')}</button>
 <div class="disclaimer">${svg('info')}<span>${['image','video','music'].includes(kind)?'Génération réelle via Replicate : des frais peuvent être facturés selon le modèle et votre compte.':'Génération réelle via votre instance Qwen/Ollama ou votre fournisseur API configuré.'}</span></div></section>
 <section class="panel preview-panel"><div class="panel-top"><h2>${kind==='app'?'Aperçu & code':'Résultat de la création'}</h2><span class="small-muted">${state.results[kind]?.status==='succeeded'?'GÉNÉRÉ':'ORBIT PREVIEW'}</span></div>${resultView(kind,state.results[kind])}<div class="preview-caption">${kind==='video'?'Une génération vidéo peut prendre plusieurs minutes. Vous pouvez naviguer dans les autres espaces pendant le calcul.':kind==='app'?'Les applications produites s’affichent dans un espace isolé, avec JavaScript et sans accès au réseau.':'Les créations finalisées sont enregistrées automatiquement dans votre bibliothèque locale.'}</div></section></div>`;
}
function promptField(kind,d){
 let lbl={image:'Décrivez votre image',video:'Décrivez votre scène',scenario:'Quelle histoire voulez-vous raconter ?',music:'Décrivez votre composition',app:'Que doit faire votre application ?'}[kind];
 let place={image:'Ex. Un portrait argentique en clair-obscur, lumière de fin de journée, grain 35mm, cadrage cinématographique…',video:'Ex. Un plan séquence lent au-dessus d’une mer agitée, lumière bleue de l’aube, caméra drone, ambiance onirique…',scenario:'Ex. Une jeune botaniste découvre une forêt capable de communiquer avec les humains…',music:'Ex. Une bande-son ambient cinématographique, nappes analogiques, cordes chaleureuses, crescendo progressif…',app:'Ex. Une application de portfolio pour un réalisateur avec une galerie, un lecteur de bande-démo et un formulaire de contact…'}[kind];
 return `<div class="field"><div class="label-with-action"><label for="main-prompt">${lbl}</label><button class="mini-wand" data-action="enhance" data-kind="${kind}">${svg('sparkles')} Améliorer avec Qwen</button></div><textarea id="main-prompt" data-field="prompt" data-kind="${kind}" placeholder="${esc(place)}">${esc(d.prompt)}</textarea></div>
 <div class="suggestion-chips">${suggestions[kind].map(x=>`<button data-suggestion="${esc(x)}" data-kind="${kind}">+ ${esc(x)}</button>`).join('')}</div>`;
}
function segment(kind,field,values,d){return `<div class="segmented">${values.map(v=>`<button data-set-field="${field}" data-value="${esc(v)}" data-kind="${kind}" class="${String(d[field])===String(v)?'selected':''}">${esc(v)}</button>`).join('')}</div>`}
function extrasFields(kind,d){
 const f=(label,content)=>`<div class="field"><label>${label}</label>${content}</div>`;
 const s=(field,arr)=>`<select data-field="${field}" data-kind="${kind}">${arr.map(v=>`<option value="${esc(v)}" ${String(d[field])===v?'selected':''}>${esc(v)}</option>`).join('')}</select>`;
 if(kind==='image')return f('Format de l’image',segment(kind,'ratio',['16:9','9:16','1:1','4:3','3:4'],d))+f('Direction artistique',s('style',['cinématographique','photographie argentique','photorealiste','editorial','minimaliste','illustration','surréaliste']));
 if(kind==='video')return `<div class="field-row">${f('Format',s('ratio',['16:9','9:16']))}${f('Durée (secondes)',s('duration',['4','6','8']))}</div>${f('Style de réalisation',s('style',['cinématographique','plan séquence','documentaire','clip musical','animation']))}<div class="field"><label><input type="checkbox" data-field="audio" data-kind="video" ${d.audio?'checked':''} style="width:auto;height:auto;margin-right:8px;accent-color:#7358e7">Générer l’audio de la vidéo</label></div>`;
 if(kind==='scenario')return `<div class="field-row">${f('Format',s('format',['Court métrage','Long métrage','Série','Documentaire','Clip musical']))}${f('Tonalité',s('tone',['Poétique','Thriller','Drame','Science-fiction','Comédie','Expérimental']))}</div>${f('Longueur cible',s('length',['2 à 3 pages','5 à 8 pages','10 à 15 pages','Synopsis détaillé']))}`;
 if(kind==='music')return `<div class="field-row">${f('Ambiance',s('mood',['Cinématique','Ambient','Épique','Mélancolique','Électronique','Organique','Mystérieuse']))}${f('Durée (secondes)',s('duration',['8','12','16','20','25','30']))}</div><div class="info-card">${svg('info')}MusicGen crée de courtes pièces musicales et non un morceau complet de plusieurs minutes. La génération est instrumentale.</div><div style="height:16px"></div>`;
 if(kind==='app')return `<div class="field-row">${f('Type de création',s('category',['Application web','Site vitrine','Portfolio','Dashboard','Jeu interactif','Outil créatif']))}${f('Style graphique',s('style',['Minimal & moderne','Éditorial','Sombre & premium','Coloré & créatif','Brutaliste','Cinématographique']))}</div><div class="info-card">${svg('info')}La génération produit une application HTML/CSS/JS autonome, prévisualisable et exportable. Les fonctions nécessitant une base de données ou un serveur doivent être développées séparément.</div><div style="height:16px"></div>`;
 return '';
}
function resultView(kind,res){
 if(!res)return `<div class="preview-box"><div class="preview-empty-icon">${svg(icons[kind])}</div><h3>La magie commence ici</h3><p>Renseignez votre brief et lancez votre première génération. Le résultat apparaîtra dans cet espace.</p></div>`;
 if(res.status==='processing')return `<div class="preview-box"><div class="loading-area"><span class="spinner"></span><strong>${kind==='video'?'Votre séquence prend forme…':'Création en cours…'}</strong><span>${esc(res.message||'L’intelligence artificielle travaille sur votre idée.')}<br/>Ne fermez pas cette page si vous souhaitez voir le résultat sans recharger.</span><div class="preview-progress"><span></span></div></div></div>`;
 if(res.status==='failed')return `<div class="result-error"><strong>La génération n’a pas abouti</strong>${esc(res.error||'Erreur inconnue.')}<p>Vérifiez vos connexions dans Paramètres, puis réessayez.</p><button class="btn-subtle" data-view="settings">Vérifier la configuration ${svg('arrow')}</button></div>`;
 if(res.status!=='succeeded')return '';
 if(kind==='scenario')return `<div class="output-view"><div class="markdown-output">${markdown(res.text)}</div></div>${actions(kind,res)}`;
 if(kind==='app')return `<div class="app-preview-tabs"><button class="${state.tab==='preview'?'selected':''}" data-action="app-tab" data-tab="preview">Aperçu interactif</button><button class="${state.tab==='code'?'selected':''}" data-action="app-tab" data-tab="code">Code HTML</button></div>${state.tab==='preview'?`<iframe id="app-preview" class="html-frame" title="Application générée" sandbox="allow-scripts" referrerpolicy="no-referrer"></iframe>`:`<div class="code-output" style="max-height:450px">${esc(res.text)}</div>`}${actions(kind,res)}`;
 const urls=res.urls||[];const url=urls[0];
 if(kind==='image')return `<div class="output-view image-result">${url?`<img src="${esc(url)}" alt="Image générée par l'IA" loading="lazy"/>`:'Aucune image renvoyée.'}</div>${actions(kind,res)}`;
 if(kind==='video')return `<div class="output-view" style="min-height:260px;display:grid;place-items:center">${url?`<video controls playsinline src="${esc(url)}"></video>`:'Aucune vidéo renvoyée.'}</div>${actions(kind,res)}`;
 if(kind==='music')return `<div class="output-view" style="min-height:240px;display:flex;flex-direction:column;align-items:center;justify-content:center"><div class="tile-art tile-art-music" style="width:100%;height:120px;border-radius:10px"><div class="art-bars">${Array(9).fill('<span></span>').join('')}</div></div><div class="output-preview-title" style="margin-top:20px">Votre composition</div>${url?`<audio controls src="${esc(url)}"></audio>`:'Aucun son renvoyé.'}</div>${actions(kind,res)}`;
 return '';
}
function markdown(text){
 // Small escaped Markdown renderer: never uses unescaped model output.
 const lines=esc(text).replace(/\r/g,'').split('\n');let code=false;let html='';
 for(const l of lines){
   if(/^```/.test(l.trim())){html+=code?'</code></pre>':'<pre><code>';code=!code;continue}
   if(code){html+=l+'\n';continue}
   const decorated=l.replace(/\*\*([^*]+)\*\*/g,'<strong>$1</strong>').replace(/\*([^*]+)\*/g,'<em>$1</em>');
   const h=decorated.match(/^(#{1,3})\s+(.+)$/);
   if(h)html+=`<h${h[1].length}>${h[2]}</h${h[1].length}>`;
   else if(!l.trim())html+='<div style="height:7px"></div>';
   else html+=`<p>${decorated}</p>`;
 }
 if(code)html+='</code></pre>';
 return html;
}
function actions(kind,res){
 const url=res.urls?.[0];
 return `<div class="output-actions">${(kind==='scenario'||kind==='app')?`<button data-action="copy" data-kind="${kind}">${svg('copy')} Copier</button>`:''}
 <button data-action="download" data-kind="${kind}">${svg('download')} Télécharger ${kind==='app'?'HTML':kind==='scenario'?'texte':'le média'}</button>${url?`<a href="${esc(url)}" target="_blank" rel="noopener noreferrer">${svg('external')} Ouvrir</a>`:''}
 <button data-view="library">${svg('folder')} Bibliothèque</button></div>`;
}
function libraryView(){
 const filtered=[...state.projects].sort(byDate).filter(p=>(state.filter==='all'||p.kind===state.filter)&&((p.title+' '+p.prompt).toLocaleLowerCase().includes(state.search.toLocaleLowerCase())));
 return `${header('Votre bibliothèque','Toutes vos créations et vos projets sauvegardés au même endroit.','ORBIT · ARCHIVES CRÉATIVES')}
 <div class="library-controls"><div class="search-wrap">${svg('search')}<input class="search-input" id="library-search" placeholder="Rechercher une création…" value="${esc(state.search)}" autocomplete="off" /></div><div class="filter-tabs">${[['all','Tous'],['image','Images'],['video','Vidéos'],['scenario','Scénarios'],['music','Audio'],['app','Apps']].map(([k,label])=>`<button data-filter="${k}" class="${state.filter===k?'active':''}">${label}</button>`).join('')}</div></div>
 ${filtered.length?`<div class="library-grid">${filtered.map(p=>`<button class="library-card" data-project="${esc(p.id)}"><div class="library-art ${esc(p.kind)}">${p.kind==='image'&&p.urls?.[0]?`<img src="${esc(p.urls[0])}" alt="Miniature de création" loading="lazy">`:svg(icons[p.kind]||'folder')}</div><div class="library-body"><strong>${esc(p.title)}</strong><p>${esc(short(p.prompt,100))}</p><div class="library-details"><span>${when(p.createdAt)}</span><span class="library-badge">${p.status==='processing'?'En cours':p.status==='failed'?'Échec':names[p.kind]}</span></div></div></button>`).join('')}</div>`:`<div class="panel empty-list" style="padding:75px 20px">${svg('folder')}<strong>Aucune création à afficher</strong>Créez un premier projet ou modifiez les filtres.<div style="margin-top:15px"><button class="btn-subtle" data-view="image">Commencer à créer ${svg('arrow')}</button></div></div>`}`;
}
function settingsView(){
 const s=state.status;
 const badge=(ok)=>(ok?'<span class="connected-badge">Connecté / configuré</span>':'<span class="disconnected-badge">À configurer</span>');
 return `${header('Moteurs & configuration','Connectez vos modèles pour donner vie à toutes vos créations.','ORBIT · CONFIGURATION')}
 <div class="settings-grid"><section class="panel settings-panel"><h2>Votre intelligence créative</h2><p>Qwen se charge des scénarios, de la création d'applications et de l'amélioration des prompts. Choisissez une exécution locale ou un fournisseur d'API compatible.</p><div class="connection-row"><div><strong>Moteur de langage</strong><small>${esc(s?.llm||'ollama')} · ${esc(s?.llm_model||'Qwen3.8 Flash Next Uncensored')}</small></div>${badge(!!s?.llm_configured)}</div><div class="connection-row"><div><strong>Génération multimédia</strong><small>Replicate · FLUX, Veo, MusicGen</small></div>${badge(!!s?.replicate)}</div><div class="info-card">${svg('info')}Pour exécuter ce modèle Qwen localement via Ollama, la version disponible exige environ 174 Go de mémoire unifiée et un Mac Apple Silicon adapté. Sur Android, utilise un fournisseur distant qui propose réellement le modèle : la version Ollama de 174 Go ne peut pas tourner sur un téléphone classique.</div></section>
 <section class="panel settings-panel"><h2>Activer les générateurs</h2><p>Ouvrez le fichier <strong>.env</strong> dans le dossier de l'application et renseignez les accès souhaités. Les clés restent côté serveur, jamais dans le navigateur.</p><div class="code-snippet">LLM_PROVIDER=ollama<br>OLLAMA_MODEL=orcarouter/Qwen3.8-Flash-Next-Uncensored<br>OLLAMA_URL=http://127.0.0.1:11434<br><br>REPLICATE_API_TOKEN=votre_cle</div><div class="output-actions"><button data-action="refresh">${svg('refresh')} Revérifier les connexions</button><button data-action="copyconfig">${svg('copy')} Copier le modèle .env</button></div></section>
 <section class="panel settings-panel"><h2>À propos des modèles</h2><div class="connection-row"><div><strong>Images</strong><small>black-forest-labs/flux-schnell</small></div><span class="library-badge">Image</span></div><div class="connection-row"><div><strong>Vidéo</strong><small>google/veo-3.1-fast</small></div><span class="library-badge">Vidéo</span></div><div class="connection-row"><div><strong>Musique</strong><small>meta/musicgen</small></div><span class="library-badge">Audio</span></div><div class="output-actions"><a href="https://ollama.com/orcarouter/Qwen3.8-Flash-Next-Uncensored" target="_blank" rel="noopener noreferrer">${svg('external')} Qwen Ollama</a><a href="https://replicate.com/account/api-tokens" target="_blank" rel="noopener noreferrer">${svg('external')} Clés Replicate</a></div></section>
 <section class="panel settings-panel"><h2>Installer l'application</h2><p>Utilise ORBIT STUDIO comme une application sur ton ordinateur ou ton téléphone. La bibliothèque et l'interface restent accessibles hors ligne après le premier chargement ; les générations IA nécessitent le serveur et Internet selon les moteurs.</p><button type="button" class="pwa-install-settings" id="pwa-install-settings">Installer ORBIT STUDIO</button><p>Sur iPhone ou iPad : Safari → Partager → « Sur l'écran d'accueil ». Sur Android : cette version est déjà installée. Pour les générations IA, ouvre « Connexions IA » dans la barre supérieure.</p></section>
 <section class="panel settings-panel"><h2>Données, confidentialité & coûts</h2><p>Le studio sauvegarde les descriptions, scénarios et projets dans ce navigateur. Les médias générés sont archivés dans le dossier <strong>media/</strong> si le téléchargement réussit. En supprimant les données du navigateur, vous perdez l'index de la bibliothèque.</p><p>Les appels multimédias sont envoyés à Replicate ; ils peuvent être facturés. Les sorties du modèle de musique peuvent avoir des restrictions de licence (notamment pour un usage commercial). Vérifiez les conditions propres à chaque modèle.</p><button class="btn-subtle" data-action="exportlibrary">${svg('download')} Exporter les métadonnées de la bibliothèque</button></section></div>`;
}
function render(){
 if(state.view==='home')root.innerHTML=homeView();
 else if(state.view==='library')root.innerHTML=libraryView();
 else if(state.view==='settings')root.innerHTML=settingsView();
 else root.innerHTML=studioView(state.view);
 if(state.view==='app'&&state.results.app?.status==='succeeded'&&state.tab==='preview')setFrame($('app-preview'),state.results.app.text);
}
function setFrame(frame,html){
 if(!frame)return;
 const csp='<meta http-equiv="Content-Security-Policy" content="default-src \'none\'; script-src \'unsafe-inline\'; style-src \'unsafe-inline\'; img-src data: blob:; font-src data:; connect-src \'none\'; form-action \'none\';">';
 const cleaned=cleanHtml(html);
 frame.srcdoc=/<head[^>]*>/i.test(cleaned)?cleaned.replace(/<head[^>]*>/i,m=>m+csp):csp+cleaned;
}
function cleanHtml(source){
 let text=String(source||'').trim();
 const fenced=text.match(/```(?:html)?\s*([\s\S]*?)```/i);
 if(fenced)text=fenced[1].trim();
 if(!/<!doctype html|<html\b/i.test(text))text=`<!doctype html><html lang="fr"><head><meta charset="utf-8"></head><body>${text}</body></html>`;
 return text;
}
function context(kind,d){
 if(kind==='scenario')return `Format : ${d.format}. Tonalité : ${d.tone}. Longueur : ${d.length}.`;
 if(kind==='app')return `Type : ${d.category}. Direction artistique : ${d.style}.`;
 return '';
}
function mediaPrompt(kind,d){
 if(kind==='image')return `${d.prompt}\nCreative direction: ${d.style}, high visual quality, deliberate composition, detail-rich.`;
 if(kind==='video')return `${d.prompt}\nFilmmaking style: ${d.style}, coherent movement, professional cinematography.`;
 if(kind==='music')return `${d.prompt}\nMood: ${d.mood}. Instrumental composition, rich cinematic soundscape.`;
 return d.prompt;
}
async function api(path,data){
 if(!navigator.onLine)throw new Error('Hors ligne : reconnecte-toi pour lancer une génération IA.');
 let response;try{response=await fetch(path,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(data)});}catch{throw new Error('Connexion au moteur IA impossible. Vérifie tes connexions IA dans les paramètres.');}
 let payload;try{payload=await response.json()}catch{throw new Error('Réponse serveur invalide.');}
 if(!response.ok)throw new Error(String(payload.error||'Erreur API.'));
 return payload;
}
function project(title,kind,prompt,other={}){return {id:crypto.randomUUID(),title:short(title,62),kind,prompt,createdAt:new Date().toISOString(),status:'succeeded',...other};}
function upsertProject(p){const ix=state.projects.findIndex(x=>x.id===p.id);if(ix<0)state.projects.unshift(p);else state.projects[ix]=p;save();}
async function generate(kind){
 if(state.busy.has(kind))return;
 const d={...state.drafts[kind]};
 if(!d.prompt.trim()){toast('Décris d’abord ton idée dans le champ de création.','error');$('main-prompt')?.focus();return;}
 state.busy.add(kind);state.results[kind]={status:'processing',message:['image','video','music'].includes(kind)?'Transmission au moteur multimédia…':'Qwen travaille sur votre brief…'};render();
 if(kind==='scenario'||kind==='app'){
   try{
     const result=await api('/api/llm',{mode:kind,prompt:d.prompt,context:context(kind,d)});
     const content=kind==='app'?cleanHtml(result.text):result.text;
     const p=project(d.prompt,kind,d.prompt,{text:content,model:result.model});upsertProject(p);
     state.results[kind]={status:'succeeded',text:content,projectId:p.id};toast('Création terminée et sauvegardée dans la bibliothèque.');
   }catch(e){state.results[kind]={status:'failed',error:e.message};toast(e.message,'error');}
   finally{state.busy.delete(kind);if(state.view===kind)render();}
   return;
 }
 try{
    const request={kind,prompt:mediaPrompt(kind,d)};
    if(kind==='image')request.ratio=d.ratio;
    if(kind==='video'){request.ratio=d.ratio;request.duration=Number(d.duration);request.audio=Boolean(d.audio);}
    if(kind==='music')request.duration=Number(d.duration);
    const response=await api('/api/create',request);
    const prediction=response.prediction||{};
    if(!prediction.id)throw new Error('Identifiant de génération absent dans la réponse.');
    const p=project(d.prompt,kind,d.prompt,{status:'processing',model:response.model,predictionId:prediction.id});upsertProject(p);
    state.results[kind]={status:'processing',message:'Calcul lancé. La génération peut prendre plusieurs minutes.'};
    if(state.view===kind)render();
    monitor(p.id);
 }catch(e){state.busy.delete(kind);state.results[kind]={status:'failed',error:e.message};if(state.view===kind)render();toast(e.message,'error');}
}
function outputUrls(value){
 if(typeof value==='string')return [value];
 if(Array.isArray(value))return value.filter(x=>typeof x==='string');
 if(value&&typeof value==='object')return Object.values(value).flatMap(outputUrls);
 return [];
}
async function monitor(pid){
 if(state.activeJobs.has(pid))return;state.activeJobs.add(pid);
 try{
   for(let tick=0;tick<180;tick++){
     const p=state.projects.find(x=>x.id===pid);if(!p||!p.predictionId)break;
     const r=await fetch('/api/prediction/'+encodeURIComponent(p.predictionId));
     const current=await r.json();if(!r.ok)throw new Error(current.error||'Impossible de consulter la génération.');
     if(current.status==='failed'||current.status==='canceled')throw new Error(String(current.error||'La génération a échoué ou a été annulée.'));
     if(current.status==='succeeded'){
       const urls=outputUrls(current.output);
       if(!urls.length)throw new Error('Le modèle n’a pas retourné de fichier média.');
       p.status='succeeded';p.urls=urls;upsertProject(p);
       state.results[p.kind]={status:'succeeded',urls,projectId:pid};
       state.busy.delete(p.kind);
       if(state.view===p.kind)render();toast('Votre création est prête et ajoutée à la bibliothèque.');
       // Archive Replicate-hosted output because prediction URLs may expire.
       if(!window.OrbitNative)try{
         const archived=await api('/api/archive',{url:urls[0],kind:p.kind});
         const latest=state.projects.find(x=>x.id===pid);
         if(latest){latest.urls=[archived.url,...urls.slice(1)];upsertProject(latest);}
         if(state.results[p.kind]?.projectId===pid)state.results[p.kind].urls=[archived.url,...urls.slice(1)];
         if(state.view===p.kind||state.view==='library')render();
       }catch(e){toast('Média généré, mais archivage local impossible : '+e.message,'error');}
       return;
     }
     if(tick%10===0&&state.view===p.kind){state.results[p.kind]={status:'processing',message:'Statut distant : '+current.status+'…'};render();}
     await new Promise(resolve=>setTimeout(resolve,4000));
   }
   throw new Error('Attente prolongée : retrouve ton projet dans la bibliothèque puis recharge la page pour reprendre le suivi.');
 }catch(e){
   const p=state.projects.find(x=>x.id===pid);
   if(p){
     // For transient network failures, allow a restart from the library.
     p.status=/Attente prolongée|connexion|consult|Hors ligne|réseau|serveur|Failed to fetch/i.test(e.message)?'processing':'failed';p.error=e.message;upsertProject(p);
     state.busy.delete(p.kind);
     state.results[p.kind]=p.status==='failed'?{status:'failed',error:e.message}:{status:'processing',message:e.message};
     if(state.view===p.kind)render();
   }
   toast(e.message,'error');
 }finally{state.activeJobs.delete(pid);}
}
async function enhance(kind){
 const d=state.drafts[kind];if(!d.prompt.trim()){toast('Décris ton idée avant de l’améliorer.','error');return;}
 if(state.busy.has(kind))return;
 state.busy.add(kind);toast('Qwen affine votre prompt…');
 try{
   const res=await api('/api/llm',{mode:'enhance',prompt:d.prompt,context:`Domaine: ${kind}`});
   d.prompt=res.text.trim();toast('Prompt amélioré. Tu peux le modifier avant de générer.');
 }catch(e){toast(e.message,'error');}
 finally{state.busy.delete(kind);if(state.view===kind)render();}
}
function downloadText(text,filename,type='text/plain;charset=utf-8'){
 if(window.OrbitNative){window.OrbitNative.saveText(String(text),String(filename),String(type));return;}const blob=new Blob([text],{type});const url=URL.createObjectURL(blob);const a=document.createElement('a');a.href=url;a.download=filename;document.body.appendChild(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(url),2000);
}
function downloadResult(kind,res){
 if(!res||res.status!=='succeeded'){toast('Aucune création finalisée à exporter.','error');return;}
 if(kind==='scenario'){downloadText(res.text,'orbit-scenario.md','text/markdown;charset=utf-8');return;}
 if(kind==='app'){downloadText(cleanHtml(res.text),'orbit-application.html','text/html;charset=utf-8');return;}
 const url=res.urls?.[0];if(!url){toast('Aucun média disponible.','error');return;}
 // Local archived media has same origin and supports true downloading; external URLs open in a new tab.
 if(url.startsWith('/media/')){const a=document.createElement('a');a.href=url;a.download='orbit-'+kind+'-'+url.split('/').pop();document.body.appendChild(a);a.click();a.remove();}
 else{if(window.OrbitNative)window.OrbitNative.downloadMedia(url,'orbit-'+kind);else window.open(url,'_blank','noopener,noreferrer');toast('Téléchargement du média demandé.');}
}
function modalFor(p){
 if(!p)return;
 state.modal=p.id;
 const status=p.status==='processing'?`<div class="loading-area"><div class="spinner"></div><strong>Génération en cours…</strong><span>Le média est en cours de calcul chez le fournisseur.</span></div>`:p.status==='failed'?`<div class="result-error">${esc(p.error||'Erreur du moteur.')}</div>`:resultView(p.kind,{status:'succeeded',text:p.text,urls:p.urls});
 $('modal').innerHTML=`<div class="modal-header"><h2>${esc(p.title)}</h2><button data-action="close-modal" aria-label="Fermer">${svg('x')}</button></div><p class="modal-subtitle">${esc(names[p.kind])} · ${when(p.createdAt)} · ${esc(p.model||'ORBIT')}</p><p class="modal-subtitle"><strong>Brief :</strong> ${esc(p.prompt)}</p>${p.kind==='app'&&p.status==='succeeded'?`<div class="app-preview-tabs"><button data-action="modal-tab" data-tab="preview" class="${state.tab==='preview'?'selected':''}">Aperçu</button><button data-action="modal-tab" data-tab="code" class="${state.tab==='code'?'selected':''}">Code</button></div>${state.tab==='preview'?'<iframe class="html-frame" id="modal-frame" title="Application générée" sandbox="allow-scripts" referrerpolicy="no-referrer"></iframe>':`<div class="code-output" style="max-height:370px">${esc(p.text)}</div>`}`:p.kind==='app'?'':status}
 <div class="modal-actions"><button class="btn-subtle danger-btn" data-action="delete" data-id="${esc(p.id)}">${svg('trash')} Supprimer</button>${p.status==='processing'?`<button class="btn-subtle" data-action="resume" data-id="${esc(p.id)}">${svg('refresh')} Reprendre le suivi</button>`:''}${p.status==='succeeded'?`<button class="btn-subtle" data-action="download-project" data-id="${esc(p.id)}">${svg('download')} Exporter</button>`:''}<button class="btn-subtle" data-action="close-modal">Fermer</button></div>`;
 $('modal-backdrop').classList.remove('hidden');
 if(p.kind==='app'&&state.tab==='preview')setFrame($('modal-frame'),p.text);
}
function closeModal(){$('modal-backdrop').classList.add('hidden');state.modal=null;}
async function copy(text){try{await navigator.clipboard.writeText(text);toast('Copié dans le presse-papiers.');}catch{downloadText(text,'orbit-copie.txt');toast('Le presse-papiers est indisponible. Texte téléchargé.');}}
function configTemplate(){return `LLM_PROVIDER=ollama\nOLLAMA_URL=http://127.0.0.1:11434\nOLLAMA_MODEL=orcarouter/Qwen3.8-Flash-Next-Uncensored\nREPLICATE_API_TOKEN=\nHOST=127.0.0.1\nPORT=8765`}
function onAction(target){
 const action=target.dataset.action;
 if(action==='generate')return generate(target.dataset.kind);
 if(action==='enhance')return enhance(target.dataset.kind);
 if(action==='app-tab'){state.tab=target.dataset.tab;render();return;}
 if(action==='download')return downloadResult(target.dataset.kind,state.results[target.dataset.kind]);
 if(action==='copy'){const r=state.results[target.dataset.kind];if(r?.text)copy(r.text);return;}
 if(action==='refresh')return refreshStatus().then(()=>toast('État des moteurs mis à jour.'));
 if(action==='copyconfig')return copy(configTemplate());
 if(action==='exportlibrary')return downloadText(JSON.stringify(state.projects,null,2),'orbit-bibliotheque.json','application/json');
 if(action==='inspire'){state.drafts.scenario.prompt='Imagine un court métrage original et visuellement marquant, où une découverte scientifique bouleverse un lien humain intime.';navigate('scenario');return;}
 if(action==='close-modal')return closeModal();
 if(action==='modal-tab'){state.tab=target.dataset.tab;modalFor(state.projects.find(p=>p.id===state.modal));return;}
 if(action==='download-project'){const p=state.projects.find(x=>x.id===target.dataset.id);if(p)downloadResult(p.kind,{status:p.status,text:p.text,urls:p.urls});return;}
 if(action==='delete'){const p=state.projects.find(x=>x.id===target.dataset.id);if(p&&confirm(`Supprimer « ${p.title} » de la bibliothèque ? Les médias archivés restent sur le disque.`)){state.projects=state.projects.filter(x=>x.id!==p.id);save();closeModal();render();toast('Projet retiré de la bibliothèque.');}return;}
 if(action==='resume'){const p=state.projects.find(x=>x.id===target.dataset.id);if(p?.predictionId){closeModal();state.busy.add(p.kind);monitor(p.id);toast('Suivi de la génération repris.');}return;}
}
document.addEventListener('click',event=>{
 const target=event.target.closest('button[data-action],button[data-view],button[data-project],button[data-filter],button[data-suggestion],button[data-set-field]');
 if(!target)return;
 if(target.dataset.action){onAction(target);return;}
 if(target.dataset.view){navigate(target.dataset.view);return;}
 if(target.dataset.project){const p=state.projects.find(x=>x.id===target.dataset.project);if(p){state.tab='preview';modalFor(p);}return;}
 if(target.dataset.filter){state.filter=target.dataset.filter;render();return;}
 if(target.dataset.suggestion){const k=target.dataset.kind;const old=state.drafts[k].prompt.trim();state.drafts[k].prompt=(old?old+'. ':'')+target.dataset.suggestion;render();$('main-prompt')?.focus();return;}
 if(target.dataset.setField){state.drafts[target.dataset.kind][target.dataset.setField]=target.dataset.value;render();return;}
});
document.addEventListener('input',event=>{
 const target=event.target;
 if(target.id==='library-search'){state.search=target.value;const selection=target.selectionStart;render();const search=$('library-search');search.focus();search.setSelectionRange(selection,selection);return;}
 if(target.dataset?.field){state.drafts[target.dataset.kind][target.dataset.field]=target.type==='checkbox'?target.checked:target.value;}
});
document.addEventListener('change',event=>{
 const target=event.target;
 if(target.dataset?.field){state.drafts[target.dataset.kind][target.dataset.field]=target.type==='checkbox'?target.checked:target.value;}
});
$('mobile-menu').addEventListener('click',()=>{$('sidebar').classList.toggle('open');$('mobile-backdrop').classList.toggle('open');});
$('mobile-backdrop').addEventListener('click',()=>{$('sidebar').classList.remove('open');$('mobile-backdrop').classList.remove('open');});
$('modal-backdrop').addEventListener('click',event=>{if(event.target===$('modal-backdrop'))closeModal();});
document.addEventListener('keydown',event=>{if(event.key==='Escape')closeModal();});
save();
const launchView=new URLSearchParams(location.search).get('view');
if(launchView && names[launchView]) navigate(launchView);
else render();
refreshStatus();
for(const p of state.projects.filter(x=>x.status==='processing'&&x.predictionId)){
 state.busy.add(p.kind);state.results[p.kind]={status:'processing',message:'Reprise du suivi après rechargement…'};
 monitor(p.id);
}
