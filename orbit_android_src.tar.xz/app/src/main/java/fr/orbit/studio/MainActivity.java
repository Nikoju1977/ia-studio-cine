package fr.orbit.studio;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.DownloadManager;
import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.Settings;
import android.text.InputType;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.webkit.JavascriptInterface;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.UUID;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends Activity {
    private static final String ORIGIN = "https://appassets.androidplatform.net";
    private final ExecutorService pool = Executors.newFixedThreadPool(3);
    private SharedPreferences preferences;
    private WebView web;
    private String pendingText;
    private static final int CREATE_TEXT_FILE = 710;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        preferences = getSharedPreferences("orbit_config", MODE_PRIVATE);
        getWindow().setStatusBarColor(Color.rgb(23, 24, 35));
        getWindow().setNavigationBarColor(Color.rgb(23, 24, 35));
        web = new WebView(this);
        web.setBackgroundColor(Color.rgb(23, 24, 35));
        setContentView(web);
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(false);
        s.setAllowContentAccess(false);
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        s.setJavaScriptCanOpenWindowsAutomatically(false);
        web.addJavascriptInterface(new NativeBridge(), "OrbitNative");
        web.setWebViewClient(new WebViewClient() {
            @Override public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest req) {
                Uri uri = req.getUrl();
                if (!"https".equals(uri.getScheme()) || !"appassets.androidplatform.net".equals(uri.getHost())) return null;
                String path = uri.getPath();
                if (path == null || path.equals("/")) path = "/index.html";
                if (path.startsWith("/static/")) path = path.substring(7);
                else if (path.startsWith("/")) path = path.substring(1);
                if (!path.matches("[a-zA-Z0-9._-]+") || path.contains(".."))
                    return new WebResourceResponse("text/plain", "UTF-8", 404, "Not found", null, new java.io.ByteArrayInputStream(new byte[0]));
                try {
                    InputStream stream = getAssets().open(path);
                    String mime = path.endsWith(".css") ? "text/css" : path.endsWith(".js") ? "application/javascript"
                        : path.endsWith(".png") ? "image/png" : path.endsWith(".html") ? "text/html" : "text/plain";
                    return new WebResourceResponse(mime, "UTF-8", stream);
                } catch (IOException err) {
                    return new WebResourceResponse("text/plain", "UTF-8", 404, "Not found", null, new java.io.ByteArrayInputStream(new byte[0]));
                }
            }
            @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri uri = request.getUrl();
                if (ORIGIN.equals(uri.getScheme()+"://"+uri.getHost())) return false;
                if (request.isForMainFrame()) {
                    try { startActivity(new Intent(Intent.ACTION_VIEW, uri)); }
                    catch (Exception ignored) { Toast.makeText(MainActivity.this, "Lien externe indisponible", Toast.LENGTH_SHORT).show(); }
                    return true;
                }
                return false;
            }
        });
        web.loadUrl(ORIGIN + "/");
    }

    @Override public void onBackPressed() {
        if (web != null && web.canGoBack()) web.goBack();
        else super.onBackPressed();
    }

    @Override protected void onDestroy() {
        if (web != null) web.destroy();
        pool.shutdownNow();
        super.onDestroy();
    }

    private class NativeBridge {
        @JavascriptInterface public void request(String id, String method, String path, String payload) {
            if (id == null || id.length() > 30 || path == null || path.length() > 200 || payload == null || payload.length() > 65536) return;
            pool.execute(() -> {
                int code = 200;
                JSONObject output;
                try { output = handle(method, path, payload); }
                catch (IllegalArgumentException e) { code = 400; output = error(e); }
                catch (Exception e) { code = 502; output = error(e); }
                try {
                    JSONObject result = new JSONObject().put("status", code).put("data", output);
                    final String script = "window.__orbitReply(" + JSONObject.quote(id) + "," + JSONObject.quote(result.toString()) + ");";
                    runOnUiThread(() -> { if (web != null) web.evaluateJavascript(script, null); });
                } catch (Exception ignored) { }
            });
        }
        @JavascriptInterface public void configure() { runOnUiThread(() -> showSettings()); }
        @JavascriptInterface public void saveText(String content, String filename, String mime) {
            if (content == null || content.length() > 5000000) return;
            runOnUiThread(() -> {
                pendingText = content;
                Intent save = new Intent(Intent.ACTION_CREATE_DOCUMENT);
                save.addCategory(Intent.CATEGORY_OPENABLE);
                save.setType(mime != null && mime.contains("/") ? mime.split(";")[0] : "text/plain");
                save.putExtra(Intent.EXTRA_TITLE, filename != null && filename.matches("[a-zA-Z0-9._-]{1,120}") ? filename : "orbit-export.txt");
                try { startActivityForResult(save, CREATE_TEXT_FILE); }
                catch (ActivityNotFoundException e) { Toast.makeText(MainActivity.this, "Aucune application de fichiers disponible", Toast.LENGTH_LONG).show(); }
            });
        }
        @JavascriptInterface public void downloadMedia(String uri, String label) {
            if (uri == null || !uri.startsWith("https://")) return;
            runOnUiThread(() -> {
                try {
                    Uri parsed = Uri.parse(uri);
                    String host = parsed.getHost() == null ? "" : parsed.getHost().toLowerCase();
                    if (!host.equals("replicate.delivery") && !host.endsWith(".replicate.delivery")) throw new IllegalArgumentException("Domaine non autorisé");
                    DownloadManager.Request req = new DownloadManager.Request(parsed);
                    req.setTitle("ORBIT STUDIO — " + (label == null ? "création" : label));
                    req.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED);
                    req.setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, "orbit-"+UUID.randomUUID()+ suffix(parsed.getPath()));
                    ((DownloadManager)getSystemService(Context.DOWNLOAD_SERVICE)).enqueue(req);
                    Toast.makeText(MainActivity.this, "Téléchargement lancé", Toast.LENGTH_SHORT).show();
                } catch (Exception e) { Toast.makeText(MainActivity.this, "Impossible de télécharger : "+e.getMessage(), Toast.LENGTH_LONG).show(); }
            });
        }
    }

    @Override protected void onActivityResult(int req, int result, Intent data) {
        super.onActivityResult(req, result, data);
        if (req == CREATE_TEXT_FILE) {
            if (result == RESULT_OK && data != null && data.getData() != null && pendingText != null) {
                try (OutputStream out = getContentResolver().openOutputStream(data.getData())) {
                    if (out == null) throw new IOException("Fichier inaccessible");
                    out.write(pendingText.getBytes(StandardCharsets.UTF_8));
                    Toast.makeText(this, "Fichier sauvegardé", Toast.LENGTH_SHORT).show();
                } catch (Exception e) { Toast.makeText(this, "Enregistrement échoué : " + e.getMessage(), Toast.LENGTH_LONG).show(); }
            }
            pendingText = null;
        }
    }

    private static String suffix(String path) {
        String ext = path == null ? "" : path.substring(path.lastIndexOf('.') + 1).toLowerCase();
        return (ext.equals("mp4") || ext.equals("webp") || ext.equals("png") || ext.equals("jpg") || ext.equals("mp3") || ext.equals("wav")) ? "."+ext : ".bin";
    }
    private static JSONObject error(Exception e) {
        try {return new JSONObject().put("error", e.getMessage() == null ? "Erreur du moteur" : e.getMessage());}
        catch (Exception ignored) {return new JSONObject();}
    }
    private String pref(String key, String fallback) { return preferences.getString(key, fallback); }

    private JSONObject handle(String method, String path, String raw) throws Exception {
        if ("GET".equals(method) && "/api/status".equals(path)) {
            boolean isOllama = pref("provider", "openai").equals("ollama");
            return new JSONObject()
                .put("llm", isOllama ? "ollama" : "openai")
                .put("llm_configured", isOllama ? !pref("ollama_url", "").isEmpty() : (!pref("api_key", "").isEmpty() && !pref("api_model", "").isEmpty()))
                .put("llm_model", isOllama ? pref("ollama_model", "orcarouter/Qwen3.8-Flash-Next-Uncensored") : pref("api_model", ""))
                .put("replicate", !pref("replicate", "").isEmpty())
                .put("image_model", "black-forest-labs/flux-schnell")
                .put("video_model", "google/veo-3.1-fast")
                .put("music_model", "meta/musicgen");
        }
        if ("GET".equals(method) && path.startsWith("/api/prediction/")) {
            String id = path.substring(16);
            if (!id.matches("[a-zA-Z0-9]{5,64}")) throw new IllegalArgumentException("Identifiant invalide");
            return http("https://api.replicate.com/v1/predictions/"+id, null, pref("replicate", ""), "GET", 90);
        }
        if (!"POST".equals(method)) throw new IllegalArgumentException("Méthode non autorisée");
        JSONObject data = new JSONObject(raw);
        if (path.equals("/api/llm")) return generateText(data);
        if (path.equals("/api/create")) return generateMedia(data);
        if (path.equals("/api/archive")) throw new IllegalArgumentException("Les médias se téléchargent sur Android via le bouton Exporter ; l'archivage n'est pas disponible.");
        throw new IllegalArgumentException("Route API inconnue");
    }

    private JSONObject generateText(JSONObject data) throws Exception {
        String mode = data.optString("mode", "scenario");
        String prompt = data.optString("prompt", "").trim();
        if (prompt.isEmpty() || prompt.length() > 12000) throw new IllegalArgumentException("Description vide ou trop longue");
        String context = data.optString("context", "");
        if (context.length() > 3000) context = context.substring(0,3000);
        if (!context.isEmpty()) prompt += "\n\nContraintes de création : " + context;
        String system;
        switch (mode) {
            case "scenario": system = "Tu es auteur-réalisateur et script doctor. Écris en français un scénario en Markdown avec titre, logline, synopsis, personnages, 3 à 5 scènes INT./EXT. et intentions de mise en scène.";break;
            case "app": system = "Tu es développeur expérimenté. Réponds UNIQUEMENT par un fichier HTML autonome complet <!DOCTYPE html> ... </html> avec CSS et JavaScript intégrés. Code utilisable hors ligne, fonctionnel et responsive, sans accès à des API ni ressources externes.";break;
            case "enhance": system = "Tu es directeur artistique. Reformule le brief en un seul prompt riche et prêt à être utilisé. Anglais pour image vidéo musique, français pour scénario/application. Réponds uniquement avec le prompt.";break;
            case "ideas": system = "Tu es directeur de création. Donne trois concepts originaux avec titre, pitch, direction artistique et étapes.";break;
            default: throw new IllegalArgumentException("Mode IA inconnu");
        }
        JSONArray msgs = new JSONArray()
            .put(new JSONObject().put("role", "system").put("content", system))
            .put(new JSONObject().put("role", "user").put("content", prompt));
        boolean ollama = pref("provider", "openai").equals("ollama");
        String model;
        JSONObject answer;
        if (ollama) {
            model = pref("ollama_model", "orcarouter/Qwen3.8-Flash-Next-Uncensored");
            String url = pref("ollama_url", "").replaceAll("/+$", "");
            if (url.isEmpty()) throw new IllegalArgumentException("Adresse du serveur Ollama distant manquante. Configure Connexions IA.");
            answer = http(url + "/api/chat", new JSONObject().put("model", model).put("stream", false)
                .put("messages", msgs).put("options", new JSONObject().put("temperature", 0.85).put("num_predict", mode.equals("app") ? 8192 : 4096)), "", "POST", 300);
            String result = answer.optJSONObject("message") == null ? "" : answer.optJSONObject("message").optString("content", "");
            if (result.isEmpty()) throw new IllegalArgumentException("Le modèle n'a renvoyé aucun texte");
            return new JSONObject().put("text",result).put("model",model);
        }
        String key = pref("api_key", "");
        model = pref("api_model", "");
        String url = pref("api_url", "https://openrouter.ai/api/v1").replaceAll("/+$", "");
        if (key.isEmpty() || model.isEmpty()) throw new IllegalArgumentException("Configure clé API et modèle dans Connexions IA.");
        if (!url.startsWith("https://")) throw new IllegalArgumentException("Le fournisseur avec clé API doit utiliser HTTPS.");
        answer = http(url + "/chat/completions", new JSONObject().put("model", model)
            .put("messages", msgs).put("temperature", 0.75).put("max_tokens", mode.equals("app") ? 8192 : 4096), key,"POST",220);
        JSONArray choices = answer.optJSONArray("choices");
        JSONObject first = choices != null && choices.length() > 0 ? choices.optJSONObject(0) : null;
        JSONObject message = first != null ? first.optJSONObject("message") : null;
        String result = message != null ? message.optString("content", "") : "";
        if (result.isEmpty()) throw new IllegalArgumentException("Le fournisseur n'a renvoyé aucun texte");
        return new JSONObject().put("text",result).put("model",model);
    }

    private JSONObject generateMedia(JSONObject data) throws Exception {
        String token = pref("replicate", "");
        if (token.isEmpty()) throw new IllegalArgumentException("Ajoute une clé Replicate via Connexions IA.");
        String kind = data.optString("kind", ""), prompt = data.optString("prompt", "").trim();
        if (prompt.isEmpty() || prompt.length() > 6000) throw new IllegalArgumentException("Prompt vide ou trop long");
        String path, model;
        JSONObject payload, input;
        if (kind.equals("image")) {
            String ratio = data.optString("ratio", "16:9");
            if (!ratio.matches("16:9|9:16|1:1|4:3|3:4|3:2|2:3")) throw new IllegalArgumentException("Ratio image inconnu");
            model = "black-forest-labs/flux-schnell";
            input = new JSONObject().put("prompt", prompt).put("aspect_ratio",ratio).put("num_outputs",1).put("output_format","webp");
            payload = new JSONObject().put("input",input);
            path = "/models/"+model+"/predictions";
        } else if (kind.equals("video")) {
            int duration = data.optInt("duration",8);
            String ratio = data.optString("ratio", "16:9");
            if (!ratio.matches("16:9|9:16") || !(duration==4 || duration==6 || duration==8)) throw new IllegalArgumentException("Durée ou format vidéo invalide");
            model = "google/veo-3.1-fast";
            input = new JSONObject().put("prompt",prompt).put("aspect_ratio",ratio).put("duration", duration).put("resolution","720p").put("generate_audio",data.optBoolean("audio",true));
            payload = new JSONObject().put("input",input);
            path = "/models/"+model+"/predictions";
        } else if (kind.equals("music")) {
            int duration = data.optInt("duration",12);
            if (duration < 4 || duration > 30) throw new IllegalArgumentException("Durée musique invalide");
            model = "meta/musicgen";
            input = new JSONObject().put("prompt",prompt).put("duration",duration).put("model_version","stereo-large").put("output_format","mp3");
            payload = new JSONObject().put("version","671ac645ce5e552cc63a54a2bbff63fcf798043055d2dac5fc9e36a837eedcfb").put("input",input);
            path = "/predictions";
        } else throw new IllegalArgumentException("Type de génération inconnu");
        return new JSONObject().put("prediction",http("https://api.replicate.com/v1"+path,payload,token,"POST",120))
            .put("model",model).put("kind",kind);
    }

    private JSONObject http(String uri, JSONObject payload, String token, String method, int timeoutSeconds) throws Exception {
        if (!uri.startsWith("https://") && !(pref("provider", "openai").equals("ollama") && uri.startsWith("http://")))
            throw new IOException("Adresse API invalide (HTTPS requis)");
        HttpURLConnection c = (HttpURLConnection)new URL(uri).openConnection();
        c.setRequestMethod(method);
        c.setConnectTimeout(15000);
        c.setReadTimeout(timeoutSeconds * 1000);
        c.setRequestProperty("Accept","application/json");
        c.setRequestProperty("User-Agent","OrbitStudioAndroid/3.0");
        c.setInstanceFollowRedirects(false);
        if (token != null && !token.isEmpty()) c.setRequestProperty("Authorization","Bearer "+token);
        if (payload != null) {
            c.setDoOutput(true);
            c.setRequestProperty("Content-Type","application/json; charset=utf-8");
            try (OutputStream out = c.getOutputStream()) {out.write(payload.toString().getBytes(StandardCharsets.UTF_8));}
        }
        int code = c.getResponseCode();
        try (InputStream input = code < 400 ? c.getInputStream() : c.getErrorStream()) {
            String body = readLimit(input, 4*1024*1024);
            if (code >= 400) throw new IOException("Service distant HTTP "+code+" : "+body.substring(0,Math.min(body.length(),1000)));
            return new JSONObject(body);
        } finally {c.disconnect();}
    }
    private static String readLimit(InputStream in, int max) throws IOException {
        if (in == null) return "";
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        byte[] buf = new byte[8192];int n;
        while ((n=in.read(buf))!=-1) {if(out.size()+n>max)throw new IOException("Réponse trop volumineuse");out.write(buf,0,n);}
        return out.toString("UTF-8");
    }

    private static EditText field(Context ctx, LinearLayout layout, String title, String value, boolean secret) {
        TextView label = new TextView(ctx);
        label.setText(title);label.setTextColor(0xff20212e);label.setTextSize(13);label.setPadding(0, 16, 0, 0);
        layout.addView(label);
        EditText edit = new EditText(ctx);
        edit.setSingleLine(true);edit.setText(value);
        edit.setTextSize(14);
        if (secret) edit.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);
        layout.addView(edit, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        return edit;
    }
    private void showSettings() {
        ScrollView scroll = new ScrollView(this);
        LinearLayout wrap = new LinearLayout(this);wrap.setOrientation(LinearLayout.VERTICAL);wrap.setPadding(32,18,32,18);
        scroll.addView(wrap);
        TextView introduction = new TextView(this);
        introduction.setText("Les modèles IA tournent sur des serveurs externes. Tes clés restent enregistrées sur cet Android. Aucun compte ni clé n'est fourni. Les générations peuvent être payantes.");
        introduction.setTextSize(13);introduction.setTextColor(0xff444455);wrap.addView(introduction);
        Spinner provider = new Spinner(this);
        provider.setAdapter(new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,new String[]{"API compatible OpenAI (OpenRouter, etc.)", "Ollama distant (Qwen3.8 Flash Next)"}));
        provider.setSelection(pref("provider","openai").equals("ollama") ? 1 : 0);
        wrap.addView(provider);
        EditText apiUrl = field(this,wrap,"URL API compatible OpenAI (HTTPS)",pref("api_url","https://openrouter.ai/api/v1"),false);
        EditText apiModel = field(this,wrap,"Identifiant du modèle sur ce fournisseur",pref("api_model",""),false);
        EditText apiKey = field(this,wrap,"Clé API du fournisseur",pref("api_key",""),true);
        EditText ollamaUrl = field(this,wrap,"URL du serveur Ollama distant (pas le téléphone)",pref("ollama_url",""),false);
        EditText ollamaModel = field(this,wrap,"Modèle Ollama",pref("ollama_model","orcarouter/Qwen3.8-Flash-Next-Uncensored"),false);
        EditText replicate = field(this,wrap,"Clé Replicate (images / vidéos / musique)",pref("replicate",""),true);
        AlertDialog dialog = new AlertDialog.Builder(this).setTitle("Connexions IA — ORBIT STUDIO").setView(scroll)
            .setNegativeButton("Annuler",(x,i)->{})
            .setPositiveButton("Enregistrer",(x,i)->{
                preferences.edit().putString("provider",provider.getSelectedItemPosition()==1 ? "ollama" : "openai")
                    .putString("api_url",apiUrl.getText().toString().trim())
                    .putString("api_model",apiModel.getText().toString().trim())
                    .putString("api_key",apiKey.getText().toString().trim())
                    .putString("ollama_url",ollamaUrl.getText().toString().trim())
                    .putString("ollama_model",ollamaModel.getText().toString().trim())
                    .putString("replicate",replicate.getText().toString().trim()).apply();
                web.evaluateJavascript("fetch('/api/status').then(r=>r.json()).then(s=>{if(typeof state !== 'undefined'){state.status=s;if(typeof render==='function')render();}})",null);
                Toast.makeText(this,"Configuration enregistrée",Toast.LENGTH_SHORT).show();
            }).create();
        dialog.show();
    }
}
